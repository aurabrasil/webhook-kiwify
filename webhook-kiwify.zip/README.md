# Webhook Kiwify → Provedor SMM

Este projeto recebe notificações de compra da **Kiwify** e envia automaticamente os dados para o **fornecedor SMM**.

## 🚀 Como usar

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Crie um arquivo `.env` com sua chave do fornecedor:
   ```
   SMM_API_KEY=SUA_CHAVE_AQUI
   ```

3. Rode o servidor:
   ```bash
   npm start
   ```

4. Configure a URL pública (Render, Railway, etc) na **Kiwify** em:
   ```
   https://SEU-SERVIDOR/render/webhook
   ```

Pronto ✅

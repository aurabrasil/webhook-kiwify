const express = require("express");
const axios = require("axios");
require("dotenv").config();

const app = express();
app.use(express.json());

app.post("/webhook", async (req, res) => {
  try {
    const data = req.body;
    console.log("📩 Webhook recebido da Kiwify:", data);

    // Exemplo: pegar email do comprador
    const email = data?.customer?.email;
    const produto = data?.product?.name;

    // Chamada ao fornecedor SMM
    const response = await axios.post("URL_DO_FORNECEDOR_SMM", {
      api_key: process.env.SMM_API_KEY,
      email: email,
      produto: produto
    });

    console.log("✅ Pedido enviado ao fornecedor:", response.data);
    res.status(200).json({ success: true });
  } catch (error) {
    console.error("❌ Erro no webhook:", error.message);
    res.status(500).json({ success: false });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Servidor rodando na porta ${PORT}`));
